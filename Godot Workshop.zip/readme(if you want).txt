For more tutorials and/or a video guide, check here!
https://www.neoxid501.com/tutorials.html

I'll hopefully have the video up in the next week or so :)